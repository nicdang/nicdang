/*************************************************************************
 *
 *	(c) 2004-05, 3DSP Corporation, all rights reserved.  Duplication or
 *	reproduction of any part of this software (source code, object code or
 *	comments) without the expressed written consent by 3DSP Corporation is
 *	forbidden.  For further information please contact:
 *
 *	3DSP Corporation
 *	16271 Laguna Canyon Rd
 *	Irvine, CA 92618
 *	www.3dsp.com 
 *
 *************************************************************************/
#ifndef _USBWLAN_VERSION_H_
#define _USBWLAN_VERSION_H_

//#include "precomp.h"

#define WLAN_DRV_NAME							"3DSP USB WLAN Driver"

#define WLAN_DRV_VERSION			"WLU100811"

#endif

